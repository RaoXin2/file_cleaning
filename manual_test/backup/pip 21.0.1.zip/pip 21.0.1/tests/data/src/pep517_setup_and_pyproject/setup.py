from setuptools import setup

setup(name="dummy", version="0.1")
