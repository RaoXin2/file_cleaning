from setuptools import setup

setup(name='requires_requires_capitalized',
      version='1.0',
      install_requires=['requires_Capitalized==0.1']
      )
