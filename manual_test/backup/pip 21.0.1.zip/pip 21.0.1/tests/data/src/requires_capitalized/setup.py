from setuptools import setup

setup(name='Requires_Capitalized',
      version='0.1',
      install_requires=['simple==1.0']
      )
