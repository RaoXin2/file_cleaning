#!/usr/bin/env python
from setuptools import setup

setup(
    name='pep518_conflicting_requires',
    version='1.0.0',
    py_modules=['pep518'],
)
