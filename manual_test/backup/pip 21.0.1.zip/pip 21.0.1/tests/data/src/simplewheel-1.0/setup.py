#!/usr/bin/env python
from setuptools import setup

import simplewheel

setup(name='simplewheel',
      version=simplewheel.__version__,
      packages=['simplewheel'],
      )
