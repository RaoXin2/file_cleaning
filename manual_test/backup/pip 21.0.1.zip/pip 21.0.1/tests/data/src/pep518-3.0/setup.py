#!/usr/bin/env python
from setuptools import setup

import simplewheel  # ensure dependency is installed

setup(name='pep518',
      version='3.0',
      py_modules=['pep518'],
      )
